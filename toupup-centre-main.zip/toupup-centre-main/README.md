# toupup-centre
> A simple and responsive Free Fire diamond top-up webpage built with HTML, CSS, and JavaScript. Designed for quick loading and mobile-friendly use. Can be easily edited in Acode and hosted on GitHub Pages.
